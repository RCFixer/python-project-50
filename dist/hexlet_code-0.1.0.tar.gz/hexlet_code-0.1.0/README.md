### Hexlet tests and linter status:
[![Actions Status](https://github.com/RCFixer/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/RCFixer/python-project-50/actions)
[![Python CI](https://github.com/RCFixer/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/RCFixer/python-project-50/actions/workflows/pyci.yml)
[![Maintainability](https://api.codeclimate.com/v1/badges/0c258f8ff07cda04d254/maintainability)](https://codeclimate.com/github/RCFixer/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/0c258f8ff07cda04d254/test_coverage)](https://codeclimate.com/github/RCFixer/python-project-50/test_coverage)

3 stage - https://asciinema.org/a/UJalGKLWbExD9n0dG6rITzjzn

5 stage - https://asciinema.org/a/MRfl73D1R7ZIDrLvlvUqDswJ5

6 stage - https://asciinema.org/a/10hFcAzXixqnzKSgbtTmrZJWo

7 stage - https://asciinema.org/a/2VsUIwgN3Z19ri0Eq3wAmeoXk